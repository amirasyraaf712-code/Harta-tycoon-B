# Build HARTA TYCOON APK using GitHub Actions from an Android phone

## Files to upload
1. Create a new GitHub repository.
2. Upload `HARTA_TYCOON_Flutter_Starter.zip` to the repository root.
3. Create a new file named `.github/workflows/build-apk.yml`.
4. Copy the contents of this workflow file into GitHub and commit it.
5. Open the repository's **Actions** tab. Select **Build HARTA TYCOON APK** and tap **Run workflow** if it has not started automatically.
6. Wait for the workflow to finish with a green check.
7. Open the successful workflow run, scroll to **Artifacts**, and download `harta-tycoon-debug-apk`.
8. Extract the downloaded artifact ZIP and install `app-debug.apk`. Android may ask you to allow installation from that source.

This workflow compiles the local demo. It does NOT enable online multiplayer yet. Firebase room sync and server-side validation remain future development work.

If the workflow fails, open the failed run, copy the last 20–40 lines of the error log, and ask for help debugging it. Do not share tokens, passwords, or private signing keys.
