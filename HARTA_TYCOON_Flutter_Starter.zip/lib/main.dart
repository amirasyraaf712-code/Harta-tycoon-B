import 'dart:math';
import 'package:flutter/material.dart';

void main() => runApp(const HartaTycoonApp());

class HartaTycoonApp extends StatelessWidget {
  const HartaTycoonApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'HARTA TYCOON',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xffd7ad54)),
      scaffoldBackgroundColor: const Color(0xfff4f2ed), useMaterial3: true),
    home: const GamePage(),
  );
}

class PropertyTile {
  final String name;
  final int price;
  final int rent;
  final String kind;
  const PropertyTile(this.name, this.price, this.rent, this.kind);
}
const board = <PropertyTile>[
  PropertyTile('START', 0, 0, 'start'),
  PropertyTile('Taman Melati', 800, 120, 'property'),
  PropertyTile('Peluang', 0, 0, 'chance'),
  PropertyTile('Bandar Baru', 1200, 180, 'property'),
  PropertyTile('Cukai', 0, 300, 'tax'),
  PropertyTile('Residensi Mewah', 1800, 300, 'property'),
  PropertyTile('Bank', 0, 0, 'bank'),
  PropertyTile('Kota Damai', 2200, 350, 'property'),
  PropertyTile('Peluang', 0, 0, 'chance'),
  PropertyTile('Pusat Niaga', 2800, 500, 'property'),
  PropertyTile('Cukai', 0, 400, 'tax'),
  PropertyTile('Skyline Tower', 3500, 700, 'property'),
];

class Player {
  String name;
  int cash, debt, position;
  Player(this.name, {this.cash = 5000, this.debt = 0, this.position = 0});
}

class GamePage extends StatefulWidget {
  const GamePage({super.key});
  @override
  State<GamePage> createState() => _GamePageState();
}

class _GamePageState extends State<GamePage> {
  final rng = Random();
  final players = [Player('Pemain 1'), Player('Pemain 2')];
  final owners = List<int>.filled(board.length, -1);
  final log = <String>['Permainan bermula. Setiap pemain menerima RM5,000.'];
  int turn = 0, round = 1;
  int? dice;
  bool get hasRolled => dice != null;
  Player get active => players[turn];
  PropertyTile get currentTile => board[active.position];

  String rm(int n) => 'RM${n.toString().replaceAllMapped(RegExp(r'(\d)(?=(\d{3})+(?!\d))'), (m) => '${m[1]},')}';
  void say(String s) { setState(() { log.insert(0, s); if (log.length > 6) log.removeLast(); }); }

  void roll() {
    if (hasRolled) return;
    final d = rng.nextInt(6) + 1;
    final old = active.position;
    final next = (old + d) % board.length;
    setState(() {
      dice = d;
      if (old + d >= board.length) active.cash += 500;
      active.position = next;
    });
    final t = board[next];
    if (t.kind == 'tax') {
      setState(() => active.cash = max(0, active.cash - t.rent));
      say('${active.name} membayar cukai ${rm(t.rent)}.');
    } else if (t.kind == 'chance') {
      final gain = rng.nextBool() ? 300 : -200;
      setState(() => active.cash = max(0, active.cash + gain));
      say('${active.name}: ${gain > 0 ? "Bonus +${rm(gain)}" : "Kos kecemasan ${rm(-gain)}"}.');
    } else if (t.kind == 'property' && owners[next] >= 0 && owners[next] != turn) {
      final owner = owners[next];
      setState(() {
        active.cash = max(0, active.cash - t.rent);
        players[owner].cash += t.rent;
      });
      say('${active.name} membayar sewa ${rm(t.rent)} kepada ${players[owner].name}.');
    } else {
      say('${active.name} baling $d dan tiba di ${t.name}.');
    }
    if (old + d >= board.length) say('${active.name} melepasi START dan menerima RM500.');
  }

  void buy() {
    final t = currentTile;
    if (!hasRolled || t.kind != 'property' || owners[active.position] != -1 || active.cash < t.price) return;
    setState(() { active.cash -= t.price; owners[active.position] = turn; });
    say('${active.name} membeli ${t.name} pada harga ${rm(t.price)}.');
  }

  void loan() {
    setState(() { active.cash += 1000; active.debt += 1000; });
    say('${active.name} meminjam RM1,000 daripada bank.');
  }

  void repay() {
    if (active.debt == 0 || active.cash == 0) {
      say(active.debt == 0 ? 'Tiada hutang untuk dibayar.' : 'Tunai tidak mencukupi.');
      return;
    }
    final amount = min(active.debt, active.cash);
    setState(() { active.cash -= amount; active.debt -= amount; });
    say('${active.name} membayar balik ${rm(amount)} kepada bank.');
  }

  void endTurn() {
    if (!hasRolled) return;
    setState(() { turn = (turn + 1) % players.length; dice = null; if (turn == 0) round++; });
    say('Giliran ${active.name}.');
  }

  void reset() => setState(() {
    players
      ..clear()
      ..addAll([Player('Pemain 1'), Player('Pemain 2')]);
    for (var i=0; i<owners.length; i++) { owners[i] = -1; }
    turn = 0; round = 1; dice = null;
    log..clear()..add('Permainan baru bermula.');
  });

  @override
  Widget build(BuildContext context) {
    final t = currentTile;
    return Scaffold(
      appBar: AppBar(title: const Text('HARTA TYCOON'), backgroundColor: const Color(0xff172c38),
        foregroundColor: Colors.white, actions: [IconButton(onPressed: reset, icon: const Icon(Icons.refresh), tooltip: 'Permainan baru')]),
      body: ListView(padding: const EdgeInsets.all(14), children: [
        Card(color: const Color(0xff172c38), child: Padding(padding: const EdgeInsets.all(14), child: Column(children: [
          Text('PUSINGAN $round', style: const TextStyle(color: Color(0xfff5d58a), fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          Row(children: List.generate(players.length, (i) => Expanded(child: Card(
            color: i == turn ? const Color(0xff365461) : const Color(0xff263e49),
            child: Padding(padding: const EdgeInsets.all(10), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(players[i].name, style: const TextStyle(color: Colors.white)),
              const SizedBox(height: 5),
              Text(rm(players[i].cash), style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
              Text('Hutang: ${rm(players[i].debt)}', style: const TextStyle(color: Colors.white70, fontSize: 12)),
              Text('${owners.where((o) => o == i).length} hartanah', style: const TextStyle(color: Colors.white70, fontSize: 12)),
            ])))))),
        ]))),
        Card(child: Padding(padding: const EdgeInsets.all(12), child: Text(log.first, style: const TextStyle(fontWeight: FontWeight.w600)))),
        GridView.builder(
          shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, childAspectRatio: .88, crossAxisSpacing: 7, mainAxisSpacing: 7),
          itemCount: board.length, itemBuilder: (context, i) {
            final p = board[i]; final owner = owners[i]; final here = players.indexWhere((x) => x.position == i);
            final color = i == active.position ? const Color(0xfff5d58a)
              : p.kind == 'property' ? (owner >= 0 ? const Color(0xffd8e8d9) : const Color(0xffe9f0f4))
              : p.kind == 'bank' ? const Color(0xffe6ddf3) : p.kind == 'tax' ? const Color(0xfff7deda) : const Color(0xfff8edcd);
            return Card(color: color, child: Padding(padding: const EdgeInsets.all(7), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Icon(p.kind == 'property' ? Icons.home_work : p.kind == 'bank' ? Icons.account_balance : p.kind == 'tax' ? Icons.receipt_long : p.kind == 'chance' ? Icons.auto_awesome : Icons.flag, size: 19),
              const SizedBox(height: 3),
              Text(p.name, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
              if (p.kind == 'property') ...[
                Text(rm(p.price), style: const TextStyle(fontSize: 11)),
                Text('Sewa ${rm(p.rent)}', style: const TextStyle(fontSize: 10)),
                Text(owner < 0 ? 'Untuk dijual' : players[owner].name, style: const TextStyle(fontSize: 10)),
              ] else if (p.kind == 'tax') Text('Bayar ${rm(p.rent)}', style: const TextStyle(fontSize: 11)),
              const Spacer(),
              if (here >= 0) Text('● P${here+1}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 11)),
            ])));
          }),
        const SizedBox(height: 12),
        Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('${active.name} • ${t.name}', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          Center(child: Text(dice?.toString() ?? '—', style: const TextStyle(fontSize: 40, fontWeight: FontWeight.bold))),
          SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: hasRolled ? null : roll, icon: const Icon(Icons.casino), label: const Text('Baling dadu'))),
          if (hasRolled && t.kind == 'property' && owners[active.position] == -1)
            SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: active.cash >= t.price ? buy : null, icon: const Icon(Icons.home), label: Text('Beli ${t.name} • ${rm(t.price)}'))),
          if (hasRolled) SizedBox(width: double.infinity, child: OutlinedButton(onPressed: endTurn, child: const Text('Tamat giliran'))),
        ]))),
        Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('BANK', style: Theme.of(context).textTheme.titleMedium),
          const Text('Pinjaman demo RM1,000 tanpa faedah automatik. Peraturan ini perlu diperhalusi sebelum online.'),
          const SizedBox(height: 8),
          Wrap(spacing: 8, children: [
            FilledButton.tonal(onPressed: hasRolled ? loan : null, child: const Text('Pinjam RM1,000')),
            OutlinedButton(onPressed: hasRolled ? repay : null, child: const Text('Bayar hutang')),
          ]),
        ]))),
        Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Rekod transaksi', style: Theme.of(context).textTheme.titleMedium),
          ...log.take(6).map((s) => ListTile(dense: true, contentPadding: EdgeInsets.zero, leading: const Icon(Icons.history), title: Text(s))),
        ]))),
        const Padding(padding: EdgeInsets.all(8), child: Text('Prototype tempatan sahaja. Online multiplayer belum disambungkan; lihat README untuk langkah Firebase.', style: TextStyle(fontSize: 12, color: Colors.black54))),
      ]),
    );
  }
}
