# HARTA TYCOON — Flutter starter

Starter prototype for an Android property board game. It currently supports a **local, two-player pass-and-play demo**: dice, property purchase, rent, tax/chance tiles, basic bank loan and repayment.

## Important status
- This is source code, not a compiled APK.
- Online multiplayer is **not connected yet**. Firebase packages are included as preparation, but Firebase setup, room codes, authenticated players, transaction validation and synchronized game state still need implementation.
- Never deploy a Firestore database with open production rules. Validate turns and money-changing actions in trusted server-side logic or restrictive transactions/security rules.

## Build an APK
Install Flutter SDK and Android Studio (including Android SDK), then open a terminal in this project folder:

```bash
flutter doctor
flutter pub get
flutter run
flutter build apk --debug
```

The debug APK should be created at:
`build/app/outputs/flutter-apk/app-debug.apk`

For a single release APK (after you have reviewed signing and tested it):
```bash
flutter build apk
```
Output: `build/app/outputs/flutter-apk/app-release.apk`

For Google Play, Flutter recommends an Android App Bundle:
```bash
flutter build appbundle
```

## Install and test
- Copy `app-debug.apk` to your Android phone and open it, allowing installation from that source if Android asks.
- Or enable Developer options and USB debugging, connect the phone to the computer, and run `flutter install`.
- Test dice movement, passing START, property buying, rent, tax, chance, loan, repayment, and turn changes.
- Test on at least two Android devices once the online room system is implemented.

## Add Firebase multiplayer
1. Create a Firebase project in the Firebase console.
2. Register the Android application using the app's application ID.
3. Install/configure FlutterFire CLI and run `flutterfire configure`.
4. Initialize Firebase in `main()` using the generated `firebase_options.dart`.
5. Enable Firebase Authentication (anonymous sign-in is acceptable for an early friend-play test).
6. Create a Firestore schema, for example `rooms/{roomCode}` with status, hostUid, currentTurn, players, board ownership, balances, debts and round number.
7. Add join-by-code and leave-room flows, Firestore snapshot listeners, and atomic turn actions.
8. Add strict Firestore Security Rules. Do not trust client-provided cash, ownership or dice results for a public release; validate actions in trusted backend logic.

Official guides:
- Flutter Android build/release: https://docs.flutter.dev/deployment/android
- Flutter Firestore multiplayer recipe: https://docs.flutter.dev/cookbook/games/firestore-multiplayer
- Firestore choice and synchronization: https://docs.flutter.dev/data-and-backend/persistence/choose-a-database

## Next development milestones
1. Add player count selection (2–4) and custom player names.
2. Add build/upgrade houses and apartment tiers.
3. Implement loan interest, collateral and bankruptcy rules.
4. Implement Firebase rooms and synchronized turn actions.
5. Add reconnect handling, anti-cheat validation, sound, polish and testing.
